namespace DMFleetManagementSystem
{
    partial class DashboardControl
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            tableLayoutPanel = new TableLayoutPanel();
            lblWelcome = new Label();
            lblDate = new Label();
            lblMessage = new Label();
            vehicleCard = new Panel();
            lblVehicleTitle = new Label();
            lblVehicleName = new Label();
            lblVehicleDetails = new Label();
            notificationCard = new Panel();
            lblNotificationTitle = new Label();
            lblUnreadNotifications = new Label();
            lblNotificationSubtitle = new Label();
            tripCard = new Panel();
            lblTripTitle = new Label();
            lblTripCount = new Label();
            lblTripSubtitle = new Label();
            logbookCard = new Panel();
            lblLogbookTitle = new Label();
            lblLogbookCount = new Label();
            lblLogbookSubtitle = new Label();
            lblRecentTitle = new Label();
            lstRecentNotifications = new ListBox();
            tableLayoutPanel.SuspendLayout();
            vehicleCard.SuspendLayout();
            notificationCard.SuspendLayout();
            tripCard.SuspendLayout();
            logbookCard.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel
            // 
            tableLayoutPanel.BackColor = SystemColors.AppWorkspace;
            tableLayoutPanel.ColumnCount = 4;
            tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel.Controls.Add(lblWelcome, 0, 0);
            tableLayoutPanel.Controls.Add(lblDate, 0, 1);
            tableLayoutPanel.Controls.Add(lblMessage, 0, 2);
            tableLayoutPanel.Controls.Add(vehicleCard, 0, 3);
            tableLayoutPanel.Controls.Add(notificationCard, 1, 3);
            tableLayoutPanel.Controls.Add(tripCard, 2, 3);
            tableLayoutPanel.Controls.Add(logbookCard, 3, 3);
            tableLayoutPanel.Controls.Add(lblRecentTitle, 0, 4);
            tableLayoutPanel.Controls.Add(lstRecentNotifications, 0, 5);
            tableLayoutPanel.Dock = DockStyle.Fill;
            tableLayoutPanel.Location = new Point(0, 0);
            tableLayoutPanel.Name = "tableLayoutPanel";
            tableLayoutPanel.Padding = new Padding(24, 20, 24, 20);
            tableLayoutPanel.RowCount = 6;
            tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 42F));
            tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 25F));
            tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
            tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 112F));
            tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 32F));
            tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel.Size = new Size(1013, 524);
            tableLayoutPanel.TabIndex = 0;
            // 
            // lblWelcome
            // 
            lblWelcome.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            lblWelcome.AutoSize = true;
            tableLayoutPanel.SetColumnSpan(lblWelcome, 4);
            lblWelcome.Font = new Font("Segoe UI", 21F, FontStyle.Bold);
            lblWelcome.ForeColor = Color.FromArgb(31, 41, 55);
            lblWelcome.Location = new Point(27, 20);
            lblWelcome.Name = "lblWelcome";
            lblWelcome.Size = new Size(260, 42);
            lblWelcome.TabIndex = 0;
            lblWelcome.Text = "Welcome back";
            // 
            // lblDate
            // 
            lblDate.Anchor = AnchorStyles.Left;
            lblDate.AutoSize = true;
            tableLayoutPanel.SetColumnSpan(lblDate, 4);
            lblDate.Font = new Font("Segoe UI", 10F);
            lblDate.ForeColor = Color.FromArgb(107, 114, 128);
            lblDate.Location = new Point(27, 63);
            lblDate.Name = "lblDate";
            lblDate.Size = new Size(54, 23);
            lblDate.TabIndex = 1;
            lblDate.Text = "Today";
            // 
            // lblMessage
            // 
            lblMessage.Anchor = AnchorStyles.Left;
            lblMessage.AutoSize = true;
            tableLayoutPanel.SetColumnSpan(lblMessage, 4);
            lblMessage.Font = new Font("Segoe UI", 10F);
            lblMessage.ForeColor = Color.FromArgb(75, 85, 99);
            lblMessage.Location = new Point(27, 90);
            lblMessage.Name = "lblMessage";
            lblMessage.Size = new Size(294, 23);
            lblMessage.TabIndex = 2;
            lblMessage.Text = "Stay safe and keep your fleet moving.";
            // 
            // vehicleCard
            // 
            ConfigureCard(vehicleCard, Color.FromArgb(235, 226, 226));
            vehicleCard.Controls.Add(lblVehicleTitle);
            vehicleCard.Controls.Add(lblVehicleName);
            vehicleCard.Controls.Add(lblVehicleDetails);
            vehicleCard.Location = new Point(27, 120);
            vehicleCard.Name = "vehicleCard";
            vehicleCard.Size = new Size(200, 100);
            vehicleCard.TabIndex = 3;
            // 
            // lblVehicleTitle
            // 
            lblVehicleTitle.Location = new Point(0, 0);
            lblVehicleTitle.Name = "lblVehicleTitle";
            lblVehicleTitle.Size = new Size(100, 23);
            lblVehicleTitle.TabIndex = 0;
            // 
            // lblVehicleName
            // 
            lblVehicleName.Location = new Point(0, 0);
            lblVehicleName.Name = "lblVehicleName";
            lblVehicleName.Size = new Size(100, 23);
            lblVehicleName.TabIndex = 1;
            // 
            // lblVehicleDetails
            // 
            lblVehicleDetails.Location = new Point(0, 0);
            lblVehicleDetails.Name = "lblVehicleDetails";
            lblVehicleDetails.Size = new Size(100, 23);
            lblVehicleDetails.TabIndex = 2;
            // 
            // notificationCard
            // 
            ConfigureCard(notificationCard, Color.FromArgb(235, 226, 226));
            notificationCard.Controls.Add(lblNotificationTitle);
            notificationCard.Controls.Add(lblUnreadNotifications);
            notificationCard.Controls.Add(lblNotificationSubtitle);
            notificationCard.Location = new Point(268, 120);
            notificationCard.Name = "notificationCard";
            notificationCard.Size = new Size(200, 100);
            notificationCard.TabIndex = 4;
            // 
            // lblNotificationTitle
            // 
            lblNotificationTitle.Location = new Point(0, 0);
            lblNotificationTitle.Name = "lblNotificationTitle";
            lblNotificationTitle.Size = new Size(100, 23);
            lblNotificationTitle.TabIndex = 0;
            // 
            // lblUnreadNotifications
            // 
            lblUnreadNotifications.Location = new Point(0, 0);
            lblUnreadNotifications.Name = "lblUnreadNotifications";
            lblUnreadNotifications.Size = new Size(100, 23);
            lblUnreadNotifications.TabIndex = 1;
            // 
            // lblNotificationSubtitle
            // 
            lblNotificationSubtitle.Location = new Point(0, 0);
            lblNotificationSubtitle.Name = "lblNotificationSubtitle";
            lblNotificationSubtitle.Size = new Size(100, 23);
            lblNotificationSubtitle.TabIndex = 2;
            // 
            // tripCard
            // 
            ConfigureCard(tripCard, Color.FromArgb(235, 226, 226));
            tripCard.Controls.Add(lblTripTitle);
            tripCard.Controls.Add(lblTripCount);
            tripCard.Controls.Add(lblTripSubtitle);
            tripCard.Location = new Point(509, 120);
            tripCard.Name = "tripCard";
            tripCard.Size = new Size(200, 100);
            tripCard.TabIndex = 5;
            // 
            // lblTripTitle
            // 
            lblTripTitle.Location = new Point(0, 0);
            lblTripTitle.Name = "lblTripTitle";
            lblTripTitle.Size = new Size(100, 23);
            lblTripTitle.TabIndex = 0;
            // 
            // lblTripCount
            // 
            lblTripCount.Location = new Point(0, 0);
            lblTripCount.Name = "lblTripCount";
            lblTripCount.Size = new Size(100, 23);
            lblTripCount.TabIndex = 1;
            // 
            // lblTripSubtitle
            // 
            lblTripSubtitle.Location = new Point(0, 0);
            lblTripSubtitle.Name = "lblTripSubtitle";
            lblTripSubtitle.Size = new Size(100, 23);
            lblTripSubtitle.TabIndex = 2;
            // 
            // logbookCard
            // 
            ConfigureCard(logbookCard, Color.FromArgb(235, 226, 226));
            logbookCard.Controls.Add(lblLogbookTitle);
            logbookCard.Controls.Add(lblLogbookCount);
            logbookCard.Controls.Add(lblLogbookSubtitle);
            ConfigureCardLabels(lblVehicleTitle, lblVehicleName, lblVehicleDetails, "Assigned vehicle", "No vehicle assigned", "Add a vehicle to get started");
            ConfigureCardLabels(lblNotificationTitle, lblUnreadNotifications, lblNotificationSubtitle, "Unread notifications", "0", "You are all caught up");
            ConfigureCardLabels(lblTripTitle, lblTripCount, lblTripSubtitle, "Trips recorded", "0", "Your trip activity");
            ConfigureCardLabels(lblLogbookTitle, lblLogbookCount, lblLogbookSubtitle, "Logbook entries", "0", "Your latest records");
            logbookCard.Location = new Point(750, 120);
            logbookCard.Name = "logbookCard";
            logbookCard.Size = new Size(200, 100);
            logbookCard.TabIndex = 6;
            // 
            // lblLogbookTitle
            // 
            lblLogbookTitle.Location = new Point(0, 0);
            lblLogbookTitle.Name = "lblLogbookTitle";
            lblLogbookTitle.Size = new Size(100, 23);
            lblLogbookTitle.TabIndex = 0;
            // 
            // lblLogbookCount
            // 
            lblLogbookCount.Location = new Point(0, 0);
            lblLogbookCount.Name = "lblLogbookCount";
            lblLogbookCount.Size = new Size(100, 23);
            lblLogbookCount.TabIndex = 1;
            // 
            // lblLogbookSubtitle
            // 
            lblLogbookSubtitle.Location = new Point(0, 0);
            lblLogbookSubtitle.Name = "lblLogbookSubtitle";
            lblLogbookSubtitle.Size = new Size(100, 23);
            lblLogbookSubtitle.TabIndex = 2;
            ConfigureCardLabels(lblVehicleTitle, lblVehicleName, lblVehicleDetails, "Assigned vehicle", "No vehicle assigned", "Add a vehicle to get started");
            ConfigureCardLabels(lblNotificationTitle, lblUnreadNotifications, lblNotificationSubtitle, "Unread notifications", "0", "You are all caught up");
            ConfigureCardLabels(lblTripTitle, lblTripCount, lblTripSubtitle, "Trips recorded", "0", "Your trip activity");
            ConfigureCardLabels(lblLogbookTitle, lblLogbookCount, lblLogbookSubtitle, "Logbook entries", "0", "Your latest records");
            // 
            // lblRecentTitle
            // 
            lblRecentTitle.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            lblRecentTitle.AutoSize = false;
            tableLayoutPanel.SetColumnSpan(lblRecentTitle, 4);
            lblRecentTitle.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblRecentTitle.ForeColor = Color.FromArgb(31, 41, 55);
            lblRecentTitle.Location = new Point(27, 233);
            lblRecentTitle.Name = "lblRecentTitle";
            lblRecentTitle.Size = new Size(959, 32);
            lblRecentTitle.TabIndex = 7;
            lblRecentTitle.Text = "Recent notifications";
            lblRecentTitle.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lstRecentNotifications
            // 
            lstRecentNotifications.BackColor = Color.FromArgb(235, 226, 226);
            lstRecentNotifications.BorderStyle = BorderStyle.FixedSingle;
            tableLayoutPanel.SetColumnSpan(lstRecentNotifications, 4);
            lstRecentNotifications.Dock = DockStyle.Fill;
            lstRecentNotifications.Font = new Font("Segoe UI", 10F);
            lstRecentNotifications.ItemHeight = 24;
            lstRecentNotifications.IntegralHeight = false;
            lstRecentNotifications.Location = new Point(27, 264);
            lstRecentNotifications.Name = "lstRecentNotifications";
            lstRecentNotifications.Size = new Size(959, 237);
            lstRecentNotifications.TabIndex = 1;
            // 
            // DashboardControl
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(tableLayoutPanel);
            Name = "DashboardControl";
            Size = new Size(1013, 524);
            Load += DashboardControl_Load;
            tableLayoutPanel.ResumeLayout(false);
            tableLayoutPanel.PerformLayout();
            vehicleCard.ResumeLayout(false);
            notificationCard.ResumeLayout(false);
            tripCard.ResumeLayout(false);
            logbookCard.ResumeLayout(false);
            ResumeLayout(false);
        }

        private void ConfigureCard(Panel card, Color accent)
        {
            card.BackColor = accent;
            card.Dock = DockStyle.Fill;
            card.Margin = new Padding(5);
            card.Padding = new Padding(14, 10, 10, 8);
            card.BorderStyle = BorderStyle.FixedSingle;
            card.Tag = accent;
        }

        private void ConfigureCardLabels(Label title, Label value, Label subtitle, string titleText, string valueText, string subtitleText)
        {
            title.AutoSize = false;
            title.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            title.ForeColor = Color.FromArgb(75, 85, 99);
            title.Location = new Point(14, 10);
            title.Size = new Size(190, 23);
            title.Text = titleText;
            value.AutoSize = false;
            value.Font = new Font("Segoe UI", 19F, FontStyle.Bold);
            value.ForeColor = Color.FromArgb(31, 41, 55);
            value.Location = new Point(14, 31);
            value.Size = new Size(210, 38);
            value.TextAlign = ContentAlignment.MiddleLeft;
            value.Text = valueText;
            subtitle.AutoSize = true;
            subtitle.Font = new Font("Segoe UI", 8.5F);
            subtitle.ForeColor = Color.FromArgb(107, 114, 128);
            subtitle.Location = new Point(14, 78);
            subtitle.Text = subtitleText;
        }

        private TableLayoutPanel tableLayoutPanel;
        private Label lblWelcome;
        private Label lblDate;
        private Label lblMessage;
        private Panel vehicleCard;
        private Label lblVehicleTitle;
        private Label lblVehicleName;
        private Label lblVehicleDetails;
        private Panel notificationCard;
        private Label lblNotificationTitle;
        private Label lblUnreadNotifications;
        private Label lblNotificationSubtitle;
        private Panel tripCard;
        private Label lblTripTitle;
        private Label lblTripCount;
        private Label lblTripSubtitle;
        private Panel logbookCard;
        private Label lblLogbookTitle;
        private Label lblLogbookCount;
        private Label lblLogbookSubtitle;
        private Label lblRecentTitle;
        private ListBox lstRecentNotifications;
    }
}