using Microsoft.Data.SqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace DMFleetManagementSystem
{
    public partial class LogbookControl : UserControl
    {
        private const string ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=DM-FleetManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";
        private int editingLogId;

        public LogbookControl()
        {
            InitializeComponent();
        }

        private void LogbookControl_Load(object? sender, EventArgs e)
        {
            LoadVehicles();
            LoadLogbook();
            ClearEditor();
        }

        private void LoadVehicles()
        {
            const string query = @"SELECT VehicleID, VehicleName, RegistrationNumber
                                   FROM Vehicles
                                   WHERE UserID = @UserID
                                   ORDER BY VehicleName";

            try
            {
                using SqlConnection connection = new SqlConnection(ConnectionString);
                using SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserID", UserSession.CurrentUserID);
                connection.Open();

                using SqlDataReader reader = command.ExecuteReader();
                cmbVehicle.Items.Clear();
                while (reader.Read())
                {
                    cmbVehicle.Items.Add(new VehicleOption
                    {
                        VehicleId = Convert.ToInt32(reader["VehicleID"]),
                        DisplayName = $"{reader["VehicleName"]} ({reader["RegistrationNumber"]})"
                    });
                }

                cmbVehicle.DisplayMember = nameof(VehicleOption.DisplayName);
                cmbVehicle.ValueMember = nameof(VehicleOption.VehicleId);
                if (cmbVehicle.Items.Count > 0)
                {
                    cmbVehicle.SelectedIndex = 0;
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Unable to load your vehicles: {ex.Message}", "Logbook", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadLogbook()
        {
            const string query = @"SELECT
                                       LogID,
                                       UserID,
                                       VehicleID,
                                       LogDate,
                                       OdemeterStart,
                                       OdemeterEnd,
                                       Purpose
                                   FROM Logbook
                                   WHERE UserID = @UserID
                                   ORDER BY LogDate DESC, LogID DESC";

            try
            {
                using SqlConnection connection = new SqlConnection(ConnectionString);
                using SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserID", UserSession.CurrentUserID);
                using SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dgvLogbook.DataSource = table;

                foreach (string columnName in new[] { "LogID", "UserID", "VehicleID" })
                {
                    if (dgvLogbook.Columns.Contains(columnName))
                    {
                        dgvLogbook.Columns[columnName].Visible = false;
                    }
                }

                if (dgvLogbook.Columns.Contains("OdemeterStart"))
                {
                    dgvLogbook.Columns["OdemeterStart"].HeaderText = "Odometer start";
                }
                if (dgvLogbook.Columns.Contains("OdemeterEnd"))
                {
                    dgvLogbook.Columns["OdemeterEnd"].HeaderText = "Odometer end";
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Unable to load the logbook: {ex.Message}", "Logbook", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAddLog_Click(object? sender, EventArgs e)
        {
            if (!TryReadEditor(out int vehicleId, out DateTime logDate, out int odometerStart, out int odometerEnd, out string purpose))
            {
                return;
            }

            const string query = @"INSERT INTO Logbook
                                   (UserID, VehicleID, LogDate, OdemeterStart, OdemeterEnd, Purpose)
                                   VALUES
                                   (@UserID, @VehicleID, @LogDate, @OdemeterStart, @OdemeterEnd, @Purpose)";

            ExecuteLogbookCommand(query, vehicleId, logDate, odometerStart, odometerEnd, purpose, "added");
        }

        private void btnEditLog_Click(object? sender, EventArgs e)
        {
            if (editingLogId == 0)
            {
                MessageBox.Show("Select a logbook row first, then click Edit selected.", "Logbook", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (!TryReadEditor(out int vehicleId, out DateTime logDate, out int odometerStart, out int odometerEnd, out string purpose))
            {
                return;
            }

            const string query = @"UPDATE Logbook
                                   SET VehicleID = @VehicleID,
                                       LogDate = @LogDate,
                                       OdemeterStart = @OdemeterStart,
                                       OdemeterEnd = @OdemeterEnd,
                                       Purpose = @Purpose
                                   WHERE LogID = @LogID AND UserID = @UserID";

            ExecuteLogbookCommand(query, vehicleId, logDate, odometerStart, odometerEnd, purpose, "updated", editingLogId);
        }

        private void btnDeleteLog_Click(object? sender, EventArgs e)
        {
            if (editingLogId == 0)
            {
                MessageBox.Show("Select a logbook row first, then click Delete.", "Logbook", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DialogResult confirmation = MessageBox.Show(
                "Delete the selected logbook entry? This cannot be undone.",
                "Delete logbook entry",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (confirmation != DialogResult.Yes)
            {
                return;
            }

            const string query = @"DELETE FROM Logbook
                                   WHERE LogID = @LogID AND UserID = @UserID";

            try
            {
                using SqlConnection connection = new SqlConnection(ConnectionString);
                using SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@LogID", editingLogId);
                command.Parameters.AddWithValue("@UserID", UserSession.CurrentUserID);
                connection.Open();
                command.ExecuteNonQuery();
                LoadLogbook();
                ClearEditor();
                MessageBox.Show("Logbook entry deleted successfully.", "Logbook", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Unable to delete the logbook entry: {ex.Message}", "Logbook", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExecuteLogbookCommand(string query, int vehicleId, DateTime logDate, int odometerStart, int odometerEnd, string purpose, string action, int? logId = null)
        {
            try
            {
                using SqlConnection connection = new SqlConnection(ConnectionString);
                using SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserID", UserSession.CurrentUserID);
                command.Parameters.AddWithValue("@VehicleID", vehicleId);
                command.Parameters.AddWithValue("@LogDate", logDate.Date);
                command.Parameters.AddWithValue("@OdemeterStart", odometerStart);
                command.Parameters.AddWithValue("@OdemeterEnd", odometerEnd);
                command.Parameters.AddWithValue("@Purpose", purpose);
                if (logId.HasValue)
                {
                    command.Parameters.AddWithValue("@LogID", logId.Value);
                }

                connection.Open();
                command.ExecuteNonQuery();
                LoadLogbook();
                ClearEditor();
                MessageBox.Show($"Logbook entry {action} successfully.", "Logbook", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Unable to save the logbook entry: {ex.Message}", "Logbook", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool TryReadEditor(out int vehicleId, out DateTime logDate, out int odometerStart, out int odometerEnd, out string purpose)
        {
            vehicleId = 0;
            logDate = dtpLogDate.Value.Date;
            odometerStart = Convert.ToInt32(nudOdometerStart.Value);
            odometerEnd = Convert.ToInt32(nudOdometerEnd.Value);
            purpose = txtPurpose.Text.Trim();

            if (cmbVehicle.SelectedItem is not VehicleOption vehicle)
            {
                MessageBox.Show("Select a vehicle first.", "Logbook", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (odometerEnd < odometerStart)
            {
                MessageBox.Show("Odometer end must be greater than or equal to odometer start.", "Logbook", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (string.IsNullOrWhiteSpace(purpose))
            {
                MessageBox.Show("Enter a purpose for this logbook entry.", "Logbook", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            vehicleId = vehicle.VehicleId;
            return true;
        }

        private void dgvLogbook_CellClick(object? sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || dgvLogbook.Rows[e.RowIndex].IsNewRow)
            {
                return;
            }

            DataGridViewRow row = dgvLogbook.Rows[e.RowIndex];
            editingLogId = Convert.ToInt32(row.Cells["LogID"].Value);
            SelectVehicle(Convert.ToInt32(row.Cells["VehicleID"].Value));
            dtpLogDate.Value = Convert.ToDateTime(row.Cells["LogDate"].Value);
            nudOdometerStart.Value = Convert.ToDecimal(row.Cells["OdemeterStart"].Value);
            nudOdometerEnd.Value = Convert.ToDecimal(row.Cells["OdemeterEnd"].Value);
            txtPurpose.Text = row.Cells["Purpose"].Value?.ToString() ?? string.Empty;
        }

        private void SelectVehicle(int vehicleId)
        {
            for (int index = 0; index < cmbVehicle.Items.Count; index++)
            {
                if (cmbVehicle.Items[index] is VehicleOption vehicle && vehicle.VehicleId == vehicleId)
                {
                    cmbVehicle.SelectedIndex = index;
                    return;
                }
            }
        }

        private void btnClear_Click(object? sender, EventArgs e) => ClearEditor();

        private void ClearEditor()
        {
            editingLogId = 0;
            dtpLogDate.Value = DateTime.Today;
            nudOdometerStart.Value = 0;
            nudOdometerEnd.Value = 0;
            txtPurpose.Clear();
            if (cmbVehicle.Items.Count > 0 && cmbVehicle.SelectedIndex < 0)
            {
                cmbVehicle.SelectedIndex = 0;
            }
            dgvLogbook.ClearSelection();
        }

        private sealed class VehicleOption
        {
            public int VehicleId { get; init; }
            public string DisplayName { get; init; } = string.Empty;
        }
    }
}
