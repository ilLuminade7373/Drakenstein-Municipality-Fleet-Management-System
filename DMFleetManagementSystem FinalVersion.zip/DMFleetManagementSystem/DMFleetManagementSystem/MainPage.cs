﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Text;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace DMFleetManagementSystem
{
    public partial class MainPage : Form
    {
        public MainPage()
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterScreen;

        }


        private void LoadControl(UserControl control)
        {
            panelContainer.Controls.Clear();
            control.Dock = DockStyle.Fill;
            panelContainer.Controls.Add(control);
        }


        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void linkLabel1_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            LoadControl(new DashboardControl());
        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel6_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login loginform = new Login();
            loginform.Show();
            this.Hide();
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {


        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void MainPage_Load(object sender, EventArgs e)
        {
            LoadUserProfileSummary();
            ShowDashboard();
        }

        private void ShowDashboard()
        {
            LoadControl(new DashboardControl());
        }

        private void LoadUserProfileSummary()
        {
            const string query = @"SELECT UserName, ProfileImagePath
                                   FROM Users
                                   WHERE UserID = @UserID";
            const string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=DM-FleetManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserID", UserSession.CurrentUserID);
                    conn.Open();

                    using SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        lblUserName.Text = reader["UserName"].ToString();
                        UserSession.CurrentUser = lblUserName.Text;

                        string imagePath = reader["ProfileImagePath"] == DBNull.Value
                            ? ""
                            : reader["ProfileImagePath"].ToString() ?? "";

                        DisplayUserImage(imagePath);
                    }
                }

                lblUserName.Left = (panel3.Width - lblUserName.Width) / 2;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to load user profile: " + ex.Message);
            }
        }

        private void DisplayUserImage(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
            {
                return;
            }

            using (Image source = Image.FromFile(path))
            {
                pictureBox1.Image = new Bitmap(source);
            }

            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            LoadControl(new VehicleControl());
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            LoadControl(new TripsControl());
        }

        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            LoadControl(new LogbookControl());
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            LoadControl(new NotificationControl());
        }

        private void label14_Click_1(object sender, EventArgs e)
        {

        }

        private void linkLabel7_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ProfileControl profileControl = new ProfileControl();
            profileControl.ProfileUpdated += ProfileControl_ProfileUpdated;
            LoadControl(profileControl);
        }

        private void ProfileControl_ProfileUpdated(object? sender, EventArgs e)
        {
            LoadUserProfileSummary();
        }

        private void btnChangePhoto_Click(object sender, EventArgs e, SqlConnection conn1)
        {
        
        }
        }
    }

