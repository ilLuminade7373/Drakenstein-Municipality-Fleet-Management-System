using Microsoft.Data.SqlClient;
using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace DMFleetManagementSystem
{
    public partial class DashboardControl : UserControl
    {
        private const string ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=DM-FleetManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";

        public DashboardControl()
        {
            InitializeComponent();
        }

        private void DashboardControl_Load(object? sender, EventArgs e)
        {
            lblWelcome.Text = $"Welcome back, {UserSession.CurrentUser ?? "Driver"}";
            lblDate.Text = DateTime.Now.ToString("dddd, dd MMMM yyyy");
            LoadDashboardData();
        }

        private void LoadDashboardData()
        {
            try
            {
                using SqlConnection connection = new SqlConnection(ConnectionString);
                connection.Open();

                LoadVehicleSummary(connection);
                LoadCounts(connection);
                LoadRecentNotifications(connection);
            }
            catch (SqlException)
            {
                lblMessage.Text = "Dashboard data is currently unavailable. Please check your database connection.";
                lstRecentNotifications.Items.Clear();
                lstRecentNotifications.Items.Add("No recent notifications available.");
            }
        }

        private void LoadVehicleSummary(SqlConnection connection)
        {
            const string query = @"SELECT TOP 1 VehicleName, RegistrationNumber, VehicleType, Status
                                   FROM Vehicles
                                   WHERE UserID = @UserID
                                   ORDER BY VehicleName";

            using SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@UserID", UserSession.CurrentUserID);
            using SqlDataReader reader = command.ExecuteReader();

            if (!reader.Read())
            {
                return;
            }

            string vehicleName = reader["VehicleName"].ToString() ?? "Assigned vehicle";
            string registration = reader["RegistrationNumber"].ToString() ?? "";
            string vehicleType = reader["VehicleType"].ToString() ?? "";
            string status = reader["Status"].ToString() ?? "";

            lblVehicleName.Text = vehicleName;
            lblVehicleDetails.Text = string.Join(" • ", new[] { registration, vehicleType, status }.Where(value => !string.IsNullOrWhiteSpace(value)));
            if (string.IsNullOrWhiteSpace(lblVehicleDetails.Text))
            {
                lblVehicleDetails.Text = "Vehicle details available";
            }
        }

        private void LoadCounts(SqlConnection connection)
        {
            const string query = @"SELECT
                                      (SELECT COUNT(*) FROM Notifications WHERE UserID = @UserID AND ISNULL(Status, '') <> 'Read') AS UnreadNotifications,
                                      (SELECT COUNT(*) FROM Trips WHERE UserID = @UserID) AS TripCount,
                                      (SELECT COUNT(*) FROM Logbook WHERE UserID = @UserID) AS LogbookCount";

            using SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@UserID", UserSession.CurrentUserID);
            using SqlDataReader reader = command.ExecuteReader();

            if (reader.Read())
            {
                lblUnreadNotifications.Text = Convert.ToInt32(reader["UnreadNotifications"]).ToString();
                lblTripCount.Text = Convert.ToInt32(reader["TripCount"]).ToString();
                lblLogbookCount.Text = Convert.ToInt32(reader["LogbookCount"]).ToString();
                lblNotificationSubtitle.Text = Convert.ToInt32(reader["UnreadNotifications"]) == 1 ? "Needs your attention" : "Need your attention";
            }
        }

        private void LoadRecentNotifications(SqlConnection connection)
        {
            const string query = @"SELECT TOP 5 Status, Message, DateSent
                                   FROM Notifications
                                   WHERE UserID = @UserID
                                   ORDER BY DateSent DESC";

            using SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@UserID", UserSession.CurrentUserID);
            using SqlDataReader reader = command.ExecuteReader();

            lstRecentNotifications.Items.Clear();
            while (reader.Read())
            {
                string status = reader["Status"].ToString() ?? "";
                string message = reader["Message"].ToString() ?? "Notification";
                string date = reader["DateSent"] == DBNull.Value
                    ? ""
                    : Convert.ToDateTime(reader["DateSent"]).ToString("dd MMM");
                string marker = string.Equals(status, "Read", StringComparison.OrdinalIgnoreCase) ? "  " : "• ";
                lstRecentNotifications.Items.Add($"{marker}{date}  {message}");
            }

            if (lstRecentNotifications.Items.Count == 0)
            {
                lstRecentNotifications.Items.Add("No notifications yet. You are all caught up.");
            }
        }

    }
}