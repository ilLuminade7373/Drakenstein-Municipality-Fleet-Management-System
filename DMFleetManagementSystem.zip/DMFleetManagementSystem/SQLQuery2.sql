﻿Select * from Vehicles;

INSERT INTO Vehicles
(UserID, VehicleName,RegistrationNumber, VehicleType, FuelType, Status)
VALUES 
(1002,'Toyota Hilux','CAA12345','Bakkie','Diesel','Active'),
(2002,'Ford Ranger','CAA23456', 'Bakkie', 'Diesel', 'Active'),
(3002,'Isuzu D-Max', 'CAA34567', 'Bakkie', 'Diesel', 'Active'),
(3003, 'Toyota Quantam', 'CAA45678', 'Minibus','Diesel', 'Active');

INSERT INTO Logbook(UserID, VehicleID, LogDate, OdemeterStart, OdemeterEnd, Purpose) 
VALUES
(1, 1, '2026-11-10', 25410, 25438, 'Fleet Inspection'),
(1,1, '2026-11-12', 25438, 25467, 'Vehicle Collection'),
(1,1, '2026-11-14', 25467,25501,'Fleet Administration'), 

(2, 2, '2026-11-10', 18750,18788, 'Document Delivery'),
(2,2, '2026-11-12', 18788, 18825, 'Municipal Office Visit'),
(2,2, '2026-11-14', 18825, 18860, 'Records Collection'),

(1002, 3,'2026-11-10',32250,32282, 'ICT Support at Civic Centre'),
(1002, 3, '2026-11-12',32282, 32318, 'Network Maintenance'),
(1002, 3, '2026-11-14',32318, 32349, 'E-Recruitment Meeting'),

(2002, 4, '2026-11-10', 48100, 48121, 'Infrastructure Inspection'),
(2002, 4, '2026-11-12', 48121, 48159, 'Site Assessment'),
(2002, 4, '2026-11-14', 48159, 48194, 'Road Maintenance Visit'),

(3002, 5,'2026-11-10', 41720, 41755, 'Community Services Visit'),
(3002,5,'2026-11-12',41755, 41797, 'Facility Inspection'),
(3002,5,'2026-11-14', 41797, 41830, 'Public Service Support'),

(3003,6,'2026-11-10',12340,12378, 'Council Administration'),
(3003,6,'2026-11-12',12378,12415,'Municipal Meeting'),
(3003,6,'2026-11-14', 12415,12456, 'Administrative Support');

Select * from Trips;

INSERT INTO Trips
(TripID, UserID, VehicleID, TripDate, StartLocation, Destination, Status)
VALUES
(1,1,1, '2026-11-16', 'Paarl Civic Centre', 'Fleet Management Meeting','Completed'),
(2,1,1, '2026-11-18', 'Municipal Stores', 'Vehicles Inspection', 'Completed'),
(3,2,2,'2026-11-16','Drakenstein Sub-Council Office', 'Document Delivery', 'Completed'),
(4,2,2,'2026-11-19', 'Wellington Office', 'Records Collection','Completed'),
(5,1002,3,'2026-11-16','Paarl Civic Centre', 'ICT Support','Completed'),
(6,1002,3, '2026-11-17', 'Wellington Office', 'Network Maintenance', 'Completed'),
(7,1002,3,'2026-11-20', 'HR Department', 'E-Recruitment Discussion', 'Completed'),
(8, 2002, 4, '2026-11-16','Infrastucture Department', 'Site Inspection','Completed'),
(9,2002,4,'2026-11-18','Road Division','Maintenance Assessment', 'Completed'),
(10, 3002,5,'2026-11-17','Community Hall','Facility Inspection', 'Completed'),
(11,3002,5,'2026-11-19','Sports Grounds','Maintenance Visit','Completed'),
(12,3003,6,'2026-11-16','Council Chambers','Administrative Support', 'Completed'),
(12,3003,6,'2026-11-19','Municipal Offices','Internal Meeting', 'Completed');

select * from Notifications;

INSERT INTO Notifications (UserID, Message, Status)
VALUES
(1, 'Monthly vehicle inspection is required.','Unread'),
(2, 'Please complete and submit your logbook entries.','Unread'),
(2,'Driver license renewal is approaching.', 'Unread'),
(1002,'Complete your daily vehicle checklist before departure.', 'Unread'),
(1002,'Remember to capture all trip information accurately.','Unread'),
(2002,'Fuel receipt submission is required for this month.', 'Unread'),
(2002,'Your assigned vehicle is scheduled for inspection.', 'Unread'),
(3002,'Outstanding logbook entries require attention.','Unread'),
(3002,'Vehicle maintenance has been scheduled.', 'Unread'),
(3003,'Monthly fleet audit reminders have been issued.','Unread'),
(3003,'Please verify vehicle information.','Unread');

Select * from Users;





