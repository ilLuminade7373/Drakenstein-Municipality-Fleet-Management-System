﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using Microsoft.Data.SqlClient;


namespace DMFleetManagementSystem
{

    public partial class ProfileControl : UserControl
    {
        public event EventHandler? ProfileUpdated;
        private readonly Button passwordToggleButton;
        private bool passwordVisible;

        public ProfileControl()
        {
            InitializeComponent();

            passwordToggleButton = new Button
            {
                Name = "passwordToggleButton",
                Text = "Show",
                Location = new Point(textBox3.Right + 8, textBox3.Top - 1),
                Size = new Size(70, textBox3.Height + 2),
                TabIndex = textBox3.TabIndex + 1,
                UseVisualStyleBackColor = true
            };

            passwordToggleButton.Click += passwordToggleButton_Click;
            Controls.Add(passwordToggleButton);
            passwordToggleButton.BringToFront();

        }



        private string imagePath = "";
        private readonly string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=DM-FleetManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";

        private void ProfileControl_Load(object sender, EventArgs e)
        {
            LoadProfile();
        }

        private void LoadProfile()
        {
            const string query = @"SELECT Username, EmailAddress, Department, Password, ProfileImagePath
                                   FROM Users
                                   WHERE UserID = @UserID";

            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@UserID", UserSession.CurrentUserID);
                conn.Open();

                using SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    textBox1.Text = reader["Username"].ToString();
                    textBox2.Text = reader["EmailAddress"].ToString();
                    textBox4.Text = reader["Department"].ToString();
                    textBox3.Text = reader["Password"].ToString();
                    imagePath = reader["ProfileImagePath"] == DBNull.Value
                        ? ""
                        : reader["ProfileImagePath"].ToString() ?? "";

                    DisplayProfileImage(imagePath);
                }
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (!passwordVisible)
            {
                textBox3.UseSystemPasswordChar = true;
            }
        }

        private void passwordToggleButton_Click(object? sender, EventArgs e)
        {
            passwordVisible = !passwordVisible;
            textBox3.UseSystemPasswordChar = !passwordVisible;
            passwordToggleButton.Text = passwordVisible ? "Hide" : "Show";
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.Filter = "Image Files|*.jpg;.jpeg;*.png;*.bmp";


            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {

                try
                {
                    string folder = Path.Combine(
                        Environment.GetFolderPath(
                                Environment.SpecialFolder.LocalApplicationData),
                            "MyApplication",
                            "ProfileImages"
                        );

                    Directory.CreateDirectory(folder);

                    string extension = Path.GetExtension(openFileDialog1.FileName);

                    string fileName = Guid.NewGuid().ToString() + extension;

                    imagePath = Path.Combine(folder, fileName);

                    File.Copy(openFileDialog1.FileName, imagePath, true);

                    DisplayProfileImage(imagePath);
                }


                catch (Exception ex)
                {
                    MessageBox.Show("Image upload error: " + ex.Message);
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string userName = textBox1.Text.Trim();
            string emailAddress = textBox2.Text.Trim();
            string department = textBox4.Text.Trim();
            string password = textBox3.Text;

            if (string.IsNullOrWhiteSpace(userName) ||
                string.IsNullOrWhiteSpace(department) ||
                string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Username, department, and password are required.");
                return;
            }

            if (!Regex.IsMatch(emailAddress, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                MessageBox.Show("Enter a valid email address.");
                return;
            }

            try
            {
                string query = @"UPDATE Users
                            SET Username = @UserName,
                            EmailAddress = @EmailAddress,
                            Department = @Department,
                            Password = @Password,
                            ProfileImagePath = @ProfileImagePath
                            WHERE UserID = @UserID
                                                ";

                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserName", userName);
                    cmd.Parameters.AddWithValue("@EmailAddress", emailAddress);
                    cmd.Parameters.AddWithValue("@Department", department);
                    cmd.Parameters.AddWithValue("@Password", password);
                    cmd.Parameters.AddWithValue("@ProfileImagePath", imagePath);
                    cmd.Parameters.AddWithValue("@UserID", UserSession.CurrentUserID);

                    conn.Open();
                    if (cmd.ExecuteNonQuery() != 1)
                    {
                        MessageBox.Show("No profile was updated. Please log in again.");
                        return;
                    }
                }

                UserSession.CurrentUser = userName;
                ProfileUpdated?.Invoke(this, EventArgs.Empty);
                MessageBox.Show("Profile updated successfully");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating profile:\n" + ex.Message);
            }
        }

        private void DisplayProfileImage(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
            {
                return;
            }

            using (Image source = Image.FromFile(path))
            {
                pictureBox1.Image?.Dispose();
                pictureBox1.Image = new Bitmap(source);
            }

            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
        }
            
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
