﻿USE [DM-FleetManagementSystem];
GO

/*
    SQLQuery2.sql - INSERTS ONLY
    This script does not update or delete existing data.
    It does not insert identity columns such as VehicleID, TripID, or LogID.
    It can be run again without inserting these same rows twice.
*/

SET XACT_ABORT ON;

BEGIN TRY
    BEGIN TRANSACTION;

    /* ------------------------ VEHICLES ------------------------ */
    DECLARE @VehicleSeed TABLE
    (
        UserID INT NOT NULL,
        VehicleName VARCHAR(100) NOT NULL,
        RegistrationNumber VARCHAR(50) NOT NULL,
        VehicleType VARCHAR(50) NOT NULL,
        FuelType VARCHAR(50) NOT NULL,
        Status VARCHAR(50) NOT NULL
    );

    INSERT INTO @VehicleSeed
        (UserID, VehicleName, RegistrationNumber, VehicleType, FuelType, Status)
    VALUES
        (1,    'Toyota Hilux',    'CAA1001', 'Bakkie',  'Diesel', 'Active'),
        (1,    'Ford Ranger',     'CAA1002', 'Bakkie',  'Diesel', 'Available'),
        (2,    'Isuzu D-Max',     'CAA2001', 'Bakkie',  'Diesel', 'Active'),
        (2,    'Toyota Corolla',  'CAA2002', 'Sedan',   'Petrol', 'Available'),
        (1002, 'Nissan NP200',    'CAA3001', 'Bakkie',  'Petrol', 'Active'),
        (1002, 'Toyota Quantum',  'CAA3002', 'Minibus', 'Diesel', 'Available'),
        (2002, 'Ford Transit',    'CAA4001', 'Minibus', 'Diesel', 'Active'),
        (2002, 'Mahindra Pik Up', 'CAA4002', 'Bakkie',  'Diesel', 'Available'),
        (3002, 'Isuzu KB',        'CAA5001', 'Bakkie',  'Diesel', 'Active'),
        (3002, 'Volkswagen Polo', 'CAA5002', 'Sedan',   'Petrol', 'Available'),
        (3003, 'Toyota Quantum',  'CAA6001', 'Minibus', 'Diesel', 'Active'),
        (3003, 'Nissan Navara',   'CAA6002', 'Bakkie',  'Diesel', 'Available');

    INSERT INTO Vehicles
        (UserID, VehicleName, RegistrationNumber, VehicleType, FuelType, Status)
    SELECT
        s.UserID,
        s.VehicleName,
        s.RegistrationNumber,
        s.VehicleType,
        s.FuelType,
        s.Status
    FROM @VehicleSeed AS s
    WHERE EXISTS
    (
        SELECT 1 FROM Users AS u WHERE u.UserID = s.UserID
    )
    AND NOT EXISTS
    (
        SELECT 1
        FROM Vehicles AS v
        WHERE v.UserID = s.UserID
          AND v.RegistrationNumber = s.RegistrationNumber
    );

    /* ------------------------- TRIPS ------------------------- */
    DECLARE @TripSeed TABLE
    (
        UserID INT NOT NULL,
        RegistrationNumber VARCHAR(50) NOT NULL,
        TripDate DATE NOT NULL,
        StartLocation VARCHAR(150) NOT NULL,
        Destination VARCHAR(150) NOT NULL,
        Status VARCHAR(50) NOT NULL
    );

    INSERT INTO @TripSeed
        (UserID, RegistrationNumber, TripDate, StartLocation, Destination, Status)
    VALUES
        (1,    'CAA1001', '2026-01-08', 'Municipal Offices',        'Paarl Civic Centre',        'Completed'),
        (1,    'CAA1002', '2026-01-15', 'Municipal Stores',          'Wellington Office',        'Completed'),
        (2,    'CAA2001', '2026-01-10', 'Drakenstein Office',        'Document Delivery',       'Completed'),
        (2,    'CAA2002', '2026-01-22', 'Wellington Office',         'Records Collection',      'Completed'),
        (1002, 'CAA3001', '2026-01-12', 'Paarl Civic Centre',        'ICT Support',             'Completed'),
        (1002, 'CAA3002', '2026-02-03', 'Municipal Offices',         'Network Maintenance',     'Completed'),
        (2002, 'CAA4001', '2026-01-17', 'Infrastructure Department', 'Site Inspection',         'Completed'),
        (2002, 'CAA4002', '2026-02-06', 'Road Division',             'Maintenance Assessment',  'Completed'),
        (3002, 'CAA5001', '2026-01-19', 'Community Hall',            'Facility Inspection',    'Completed'),
        (3002, 'CAA5002', '2026-02-10', 'Sports Grounds',             'Maintenance Visit',      'Completed'),
        (3003, 'CAA6001', '2026-01-25', 'Council Chambers',          'Administrative Support', 'Completed'),
        (3003, 'CAA6002', '2026-02-12', 'Municipal Offices',         'Internal Meeting',       'Completed');

    INSERT INTO Trips
        (UserID, VehicleID, TripDate, StartLocation, Destination, Status)
    SELECT
        s.UserID,
        v.VehicleID,
        s.TripDate,
        s.StartLocation,
        s.Destination,
        s.Status
    FROM @TripSeed AS s
    INNER JOIN Vehicles AS v
        ON v.UserID = s.UserID
       AND v.RegistrationNumber = s.RegistrationNumber
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM Trips AS t
        WHERE t.UserID = s.UserID
          AND t.VehicleID = v.VehicleID
          AND t.TripDate = s.TripDate
          AND t.StartLocation = s.StartLocation
          AND t.Destination = s.Destination
    );

    /* ----------------------- LOGBOOK ------------------------- */
    DECLARE @LogbookSeed TABLE
    (
        UserID INT NOT NULL,
        RegistrationNumber VARCHAR(50) NOT NULL,
        LogDate DATE NOT NULL,
        OdemeterStart INT NOT NULL,
        OdemeterEnd INT NOT NULL,
        Purpose VARCHAR(200) NOT NULL
    );

    INSERT INTO @LogbookSeed
        (UserID, RegistrationNumber, LogDate, OdemeterStart, OdemeterEnd, Purpose)
    VALUES
        (1,    'CAA1001', '2026-01-08', 12500, 12538, 'Fleet inspection'),
        (1,    'CAA1002', '2026-01-15', 18700, 18742, 'Document delivery'),
        (2,    'CAA2001', '2026-01-10', 21300, 21337, 'Municipal office visit'),
        (2,    'CAA2002', '2026-01-22', 30200, 30244, 'Records collection'),
        (1002, 'CAA3001', '2026-01-12', 32250, 32282, 'ICT support at civic centre'),
        (1002, 'CAA3002', '2026-02-03', 41000, 41036, 'Network maintenance'),
        (2002, 'CAA4001', '2026-01-17', 48100, 48121, 'Infrastructure inspection'),
        (2002, 'CAA4002', '2026-02-06', 52600, 52638, 'Road maintenance visit'),
        (3002, 'CAA5001', '2026-01-19', 41720, 41755, 'Community services visit'),
        (3002, 'CAA5002', '2026-02-10', 63500, 63542, 'Facility inspection'),
        (3003, 'CAA6001', '2026-01-25', 12340, 12378, 'Council administration'),
        (3003, 'CAA6002', '2026-02-12', 27800, 27835, 'Internal meeting');

    INSERT INTO Logbook
        (UserID, VehicleID, LogDate, OdemeterStart, OdemeterEnd, Purpose)
    SELECT
        s.UserID,
        v.VehicleID,
        s.LogDate,
        s.OdemeterStart,
        s.OdemeterEnd,
        s.Purpose
    FROM @LogbookSeed AS s
    INNER JOIN Vehicles AS v
        ON v.UserID = s.UserID
       AND v.RegistrationNumber = s.RegistrationNumber
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM Logbook AS l
        WHERE l.UserID = s.UserID
          AND l.VehicleID = v.VehicleID
          AND l.LogDate = s.LogDate
          AND l.OdemeterStart = s.OdemeterStart
          AND l.OdemeterEnd = s.OdemeterEnd
    );

    /* --------------------- NOTIFICATIONS --------------------- */
    DECLARE @NotificationSeed TABLE
    (
        UserID INT NOT NULL,
        Message VARCHAR(500) NOT NULL
    );

    INSERT INTO @NotificationSeed (UserID, Message)
    VALUES
        (1,    'Monthly vehicle inspection is required.'),
        (1,    'Please submit your latest logbook entries.'),
        (2,    'Your assigned vehicle is scheduled for inspection.'),
        (2,    'Fuel receipt submission is required this month.'),
        (1002, 'Complete your daily vehicle checklist before departure.'),
        (1002, 'Remember to capture all trip information accurately.'),
        (2002, 'A maintenance assessment is scheduled for your vehicle.'),
        (2002, 'Please verify your trip information before submission.'),
        (3002, 'Outstanding logbook entries require attention.'),
        (3002, 'Vehicle maintenance has been scheduled.'),
        (3003, 'Monthly fleet audit reminders have been issued.'),
        (3003, 'Please verify your vehicle information.');

    INSERT INTO Notifications (UserID, Message, Status)
    SELECT s.UserID, s.Message, 'Unread'
    FROM @NotificationSeed AS s
    WHERE EXISTS
    (
        SELECT 1 FROM Users AS u WHERE u.UserID = s.UserID
    )
    AND NOT EXISTS
    (
        SELECT 1
        FROM Notifications AS n
        WHERE n.UserID = s.UserID
          AND n.Message = s.Message
    );

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;

    THROW;
END CATCH;
GO

-- Optional check after the inserts.
SELECT CAST('Vehicles' AS VARCHAR(20)) AS TableName,
       COUNT_BIG(*) AS TotalRows
FROM Vehicles
UNION ALL
SELECT CAST('Trips' AS VARCHAR(20)), COUNT_BIG(*)
FROM Trips
UNION ALL
SELECT CAST('Logbook' AS VARCHAR(20)), COUNT_BIG(*)
FROM Logbook
UNION ALL
SELECT CAST('Notifications' AS VARCHAR(20)), COUNT_BIG(*)
FROM Notifications;
GO




