﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Linq.Expressions;
using Microsoft.Data.SqlClient;


namespace DMFleetManagementSystem
{

    public partial class ProfileControl : UserControl
    {
        public ProfileControl()
        {
            InitializeComponent();

        }



        private string newImagePath = "";
        private string OriginalUsername;

        private void ProfileControl_Load(object sender, EventArgs e)
        {
            LoadProfile();
        }

        private void LoadProfile()
        {
            SqlConnection conn = new SqlConnection(connectionString);

            string query = "SELECT * FROM Users WHERE UserID = @UserID";

            SqlCommand cmd = new SqlCommand(query, conn);

            cmd.Parameters.AddWithValue("@UserID", UserSession.CurrentUserID);

            conn.Open();

            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read()) {

                textBox1.Text = reader["Username"].ToString();
                textBox2.Text = reader["EmailAddress"].ToString();
                textBox4.Text = reader["Department"].ToString();
                textBox3.Text = reader["Password"].ToString();


            }
            conn.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            textBox3.UseSystemPasswordChar = true;
        }
        string imagePath = "";
        string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=DM-FleetManagementSystem;Integrated Security=True;Encrypt=True";


        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.Filter = "Image Files|*.jpg;.jpeg;*.png;*.bmp";


            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {

                try
                {
                    string folder = Path.Combine(
                        Environment.GetFolderPath(
                                Environment.SpecialFolder.LocalApplicationData),
                            "MyApplication",
                            "ProfileImages"
                        );

                    Directory.CreateDirectory(folder);

                    string extension = Path.GetExtension(openFileDialog1.FileName);

                    string fileName = Guid.NewGuid().ToString() + extension;

                    imagePath = Path.Combine(folder, fileName);

                    File.Copy(openFileDialog1.FileName, imagePath, true);

                    using (Image img = Image.FromFile(imagePath))
                    {
                        pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
                    }
                }


                catch (Exception ex)
                {
                    MessageBox.Show("Image upload error: " + ex.Message);
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {    try
            {
                SqlConnection conn = new SqlConnection(connectionString);

                string query = @"UPDATE Users
                            SET Username = @UserName,
                            EmailAddress = @EmailAddress,
                            Department = @Department,
                            Password = @Password,
                            ProfileImagePath = @ProfileImagePath
                                                ";
                SqlCommand cmd = new SqlCommand(query, conn);

                cmd.Parameters.AddWithValue("@UserName", textBox1);
                cmd.Parameters.AddWithValue("@EmailAddress", textBox2);
                cmd.Parameters.AddWithValue("@Department", textBox4);
                cmd.Parameters.AddWithValue("@Password", textBox3);
                cmd.Parameters.AddWithValue("@ProfileImagePath", imagePath);
                cmd.Parameters.AddWithValue("@UserID", UserSession.CurrentUserID);

                conn.Open();

                cmd.ExecuteNonQuery();

                conn.Close();

                MessageBox.Show("Profile updated successfully");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating profile:\n" + ex.Message);
            }
            }
            
        // the whole purpose of this code was to update user current info and save it. image should appear in picture box after save etc.
            
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
