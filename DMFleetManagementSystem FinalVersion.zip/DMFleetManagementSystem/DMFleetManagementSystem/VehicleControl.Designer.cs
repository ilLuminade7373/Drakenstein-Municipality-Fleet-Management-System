namespace DMFleetManagementSystem
{
    partial class VehicleControl
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            lblVehicleName = new Label();
            lblRegistrationNumber = new Label();
            lblVehicleType = new Label();
            lblFuelType = new Label();
            lblStatus = new Label();
            lblVehicleSubtitle = new Label();
            lblVehicleNameDetail = new Label();
            lblVehicleSummary = new Label();
            vehicleIcon = new Label();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.BackColor = SystemColors.AppWorkspace;
            tableLayoutPanel1.ColumnCount = 3;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));
            tableLayoutPanel1.Controls.Add(label1, 1, 0);
            tableLayoutPanel1.Controls.Add(lblVehicleSubtitle, 1, 1);
            tableLayoutPanel1.Controls.Add(label2, 0, 2);
            tableLayoutPanel1.Controls.Add(lblVehicleName, 1, 2);
            tableLayoutPanel1.Controls.Add(label3, 0, 3);
            tableLayoutPanel1.Controls.Add(lblRegistrationNumber, 1, 3);
            tableLayoutPanel1.Controls.Add(label4, 0, 4);
            tableLayoutPanel1.Controls.Add(lblVehicleType, 1, 4);
            tableLayoutPanel1.Controls.Add(label5, 0, 5);
            tableLayoutPanel1.Controls.Add(lblFuelType, 1, 5);
            tableLayoutPanel1.Controls.Add(label6, 0, 6);
            tableLayoutPanel1.Controls.Add(lblStatus, 1, 6);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Padding = new Padding(170, 18, 170, 30);
            tableLayoutPanel1.RowCount = 7;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 55F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 35F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.Size = new Size(1035, 594);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Dock = DockStyle.Fill;
            label1.Font = new Font("Segoe UI", 22.2F, FontStyle.Bold | FontStyle.Italic);
            label1.ForeColor = Color.FromArgb(31, 41, 55);
            label1.Text = "MyVehicle";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblVehicleSubtitle
            // 
            lblVehicleSubtitle.AutoSize = true;
            lblVehicleSubtitle.Dock = DockStyle.Fill;
            lblVehicleSubtitle.Font = new Font("Segoe UI", 9.5F, FontStyle.Italic);
            lblVehicleSubtitle.ForeColor = Color.FromArgb(75, 85, 99);
            lblVehicleSubtitle.Text = "Your assigned vehicle details";
            lblVehicleSubtitle.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // captions
            // 
            ConfigureCaption(label2, "Vehicle Name:");
            ConfigureCaption(label3, "Registration Number:");
            ConfigureCaption(label4, "Vehicle Type:");
            ConfigureCaption(label5, "Fuel Type:");
            ConfigureCaption(label6, "Status:");
            // 
            // values
            // 
            ConfigureValue(lblVehicleName, "No vehicle assigned");
            ConfigureValue(lblRegistrationNumber, "Not available");
            ConfigureValue(lblVehicleType, "Not available");
            ConfigureValue(lblFuelType, "Not available");
            ConfigureValue(lblStatus, "Not assigned");
            // Hidden compatibility fields used when loading the vehicle summary.
            lblVehicleNameDetail.Visible = false;
            lblVehicleSummary.Visible = false;
            vehicleIcon.Visible = false;
            // 
            // VehicleControl
            // 
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(tableLayoutPanel1);
            Name = "VehicleControl";
            Size = new Size(1035, 594);
            Load += VehicleControl_Load;
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }

        private void ConfigureCaption(Label label, string text)
        {
            label.AutoSize = true;
            label.Dock = DockStyle.Fill;
            label.Font = new Font("Segoe UI", 13.8F);
            label.ForeColor = Color.FromArgb(55, 65, 81);
            label.Text = text;
            label.TextAlign = ContentAlignment.MiddleRight;
            label.Padding = new Padding(0, 0, 18, 0);
        }

        private void ConfigureValue(Label label, string text)
        {
            label.AutoSize = true;
            label.Dock = DockStyle.Fill;
            label.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            label.ForeColor = Color.FromArgb(31, 41, 55);
            label.Text = text;
            label.TextAlign = ContentAlignment.MiddleLeft;
            label.Padding = new Padding(14, 0, 0, 0);
        }

        private TableLayoutPanel tableLayoutPanel1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label lblVehicleName;
        private Label lblRegistrationNumber;
        private Label lblVehicleType;
        private Label lblFuelType;
        private Label lblStatus;
        private Label lblVehicleSubtitle;
        private Label lblVehicleNameDetail;
        private Label lblVehicleSummary;
        private Label vehicleIcon;
    }
}