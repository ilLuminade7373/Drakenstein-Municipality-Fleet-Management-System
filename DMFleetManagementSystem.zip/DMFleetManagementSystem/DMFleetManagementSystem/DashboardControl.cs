﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DMFleetManagementSystem
{
    public partial class DashboardControl : UserControl
    {
        public DashboardControl()
        {
            InitializeComponent();

        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void DashboardControl_Load(object sender, EventArgs e)
        {



        }

        private void DashboardControl_Load_1(object sender, EventArgs e)
        {
            lblWelcome.Text = "Welcome Back, " + UserSession.CurrentUser;

            lblDate1.Text = DateTime.Now.ToString("dddd, dd MMM yyyy");
            lblMessage.Text = "Have a productive day and drive safely.";
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
