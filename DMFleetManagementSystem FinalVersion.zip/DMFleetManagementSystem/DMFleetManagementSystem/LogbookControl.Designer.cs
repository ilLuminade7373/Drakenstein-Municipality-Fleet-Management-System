namespace DMFleetManagementSystem
{
    partial class LogbookControl
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            label1 = new Label();
            editorPanel = new Panel();
            lblVehicle = new Label();
            cmbVehicle = new ComboBox();
            lblLogDate = new Label();
            dtpLogDate = new DateTimePicker();
            lblOdometerStart = new Label();
            nudOdometerStart = new NumericUpDown();
            lblOdometerEnd = new Label();
            nudOdometerEnd = new NumericUpDown();
            lblPurpose = new Label();
            txtPurpose = new TextBox();
            btnAddLog = new Button();
            btnEditLog = new Button();
            btnDeleteLog = new Button();
            btnClear = new Button();
            dgvLogbook = new DataGridView();
            editorPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudOdometerStart).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudOdometerEnd).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvLogbook).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Font = new Font("Segoe UI", 22.2F, FontStyle.Bold | FontStyle.Italic);
            label1.Location = new Point(420, 0);
            label1.Name = "label1";
            label1.Size = new Size(171, 52);
            label1.TabIndex = 3;
            label1.Text = "Logbook";
            // 
            // editorPanel
            // 
            editorPanel.BackColor = SystemColors.AppWorkspace;
            editorPanel.BorderStyle = BorderStyle.FixedSingle;
            editorPanel.Controls.Add(lblVehicle);
            editorPanel.Controls.Add(cmbVehicle);
            editorPanel.Controls.Add(lblLogDate);
            editorPanel.Controls.Add(dtpLogDate);
            editorPanel.Controls.Add(lblOdometerStart);
            editorPanel.Controls.Add(nudOdometerStart);
            editorPanel.Controls.Add(lblOdometerEnd);
            editorPanel.Controls.Add(nudOdometerEnd);
            editorPanel.Controls.Add(lblPurpose);
            editorPanel.Controls.Add(txtPurpose);
            editorPanel.Controls.Add(btnAddLog);
            editorPanel.Controls.Add(btnEditLog);
            editorPanel.Controls.Add(btnDeleteLog);
            editorPanel.Controls.Add(btnClear);
            editorPanel.Location = new Point(23, 63);
            editorPanel.Name = "editorPanel";
            editorPanel.Size = new Size(955, 95);
            editorPanel.TabIndex = 4;
            // 
            // editor labels and controls
            // 
            ConfigureEditorLabel(lblVehicle, "Vehicle", 16, 12);
            ConfigureEditorLabel(lblLogDate, "Date", 174, 12);
            ConfigureEditorLabel(lblOdometerStart, "Odometer start", 332, 12);
            ConfigureEditorLabel(lblOdometerEnd, "Odometer end", 472, 12);
            ConfigureEditorLabel(lblPurpose, "Purpose", 612, 12);
            cmbVehicle.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbVehicle.Location = new Point(16, 39);
            cmbVehicle.Name = "cmbVehicle";
            cmbVehicle.Size = new Size(145, 28);
            cmbVehicle.TabIndex = 0;
            dtpLogDate.Format = DateTimePickerFormat.Short;
            dtpLogDate.Location = new Point(174, 39);
            dtpLogDate.Name = "dtpLogDate";
            dtpLogDate.Size = new Size(140, 27);
            dtpLogDate.TabIndex = 1;
            nudOdometerStart.Location = new Point(332, 39);
            nudOdometerStart.Maximum = new decimal(new int[] { 10000000, 0, 0, 0 });
            nudOdometerStart.Name = "nudOdometerStart";
            nudOdometerStart.Size = new Size(120, 27);
            nudOdometerStart.TabIndex = 2;
            nudOdometerEnd.Location = new Point(472, 39);
            nudOdometerEnd.Maximum = new decimal(new int[] { 10000000, 0, 0, 0 });
            nudOdometerEnd.Name = "nudOdometerEnd";
            nudOdometerEnd.Size = new Size(120, 27);
            nudOdometerEnd.TabIndex = 3;
            txtPurpose.Location = new Point(612, 39);
            txtPurpose.Name = "txtPurpose";
            txtPurpose.Size = new Size(155, 27);
            txtPurpose.TabIndex = 4;
            cmbVehicle.BackColor = Color.FromArgb(245, 245, 245);
            dtpLogDate.CalendarMonthBackground = Color.FromArgb(245, 245, 245);
            nudOdometerStart.BackColor = Color.FromArgb(245, 245, 245);
            nudOdometerEnd.BackColor = Color.FromArgb(245, 245, 245);
            txtPurpose.BackColor = Color.FromArgb(245, 245, 245);
            ConfigureActionButton(btnAddLog, "Add log", btnAddLog_Click, 770);
            ConfigureActionButton(btnEditLog, "Edit selected", btnEditLog_Click, 770, 41);
            ConfigureActionButton(btnDeleteLog, "Delete", btnDeleteLog_Click, 860);
            ConfigureActionButton(btnClear, "Clear", btnClear_Click, 860, 41);
            // 
            // dgvLogbook
            // 
            dgvLogbook.AllowUserToAddRows = false;
            dgvLogbook.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvLogbook.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvLogbook.Location = new Point(23, 170);
            dgvLogbook.MultiSelect = false;
            dgvLogbook.Name = "dgvLogbook";
            dgvLogbook.ReadOnly = true;
            dgvLogbook.BackgroundColor = SystemColors.AppWorkspace;
            dgvLogbook.DefaultCellStyle.BackColor = Color.FromArgb(245, 245, 245);
            dgvLogbook.DefaultCellStyle.SelectionBackColor = Color.FromArgb(75, 85, 99);
            dgvLogbook.RowHeadersWidth = 51;
            dgvLogbook.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvLogbook.Size = new Size(955, 380);
            dgvLogbook.TabIndex = 5;
            dgvLogbook.CellClick += dgvLogbook_CellClick;
            // 
            // LogbookControl
            // 
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(dgvLogbook);
            Controls.Add(editorPanel);
            Controls.Add(label1);
            ForeColor = Color.FromArgb(31, 41, 55);
            Name = "LogbookControl";
            Size = new Size(1002, 588);
            Load += LogbookControl_Load;
            editorPanel.ResumeLayout(false);
            editorPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudOdometerStart).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudOdometerEnd).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvLogbook).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private void ConfigureEditorLabel(Label label, string text, int x, int y)
        {
            label.AutoSize = true;
            label.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
            label.Location = new Point(x, y);
            label.Text = text;
        }

        private void ConfigureActionButton(Button button, string text, EventHandler handler, int x, int y = 12)
        {
            button.BackColor = Color.FromArgb(75, 85, 99);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.ForeColor = Color.White;
            button.Location = new Point(x, y);
            button.Name = text.Replace(" ", "");
            button.Size = new Size(84, 28);
            button.TabIndex = 5;
            button.Text = text;
            button.UseVisualStyleBackColor = false;
            button.Click += handler;
        }

        private Label label1;
        private Panel editorPanel;
        private Label lblVehicle;
        private ComboBox cmbVehicle;
        private Label lblLogDate;
        private DateTimePicker dtpLogDate;
        private Label lblOdometerStart;
        private NumericUpDown nudOdometerStart;
        private Label lblOdometerEnd;
        private NumericUpDown nudOdometerEnd;
        private Label lblPurpose;
        private TextBox txtPurpose;
        private Button btnAddLog;
        private Button btnEditLog;
        private Button btnDeleteLog;
        private Button btnClear;
        private DataGridView dgvLogbook;
    }
}
