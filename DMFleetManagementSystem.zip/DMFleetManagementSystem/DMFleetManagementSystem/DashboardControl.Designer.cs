﻿namespace DMFleetManagementSystem
{
    partial class DashboardControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            lblWelcome = new Label();
            lblDate1 = new Label();
            lblMessage = new Label();
            label8 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Font = new Font("Segoe UI", 22.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(451, 0);
            label1.Name = "label1";
            label1.Size = new Size(212, 52);
            label1.TabIndex = 0;
            label1.Text = "HomePage";
            // 
            // lblWelcome
            // 
            lblWelcome.AutoSize = true;
            lblWelcome.Font = new Font("Segoe UI", 16.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
            lblWelcome.Location = new Point(402, 99);
            lblWelcome.Name = "lblWelcome";
            lblWelcome.Size = new Size(90, 38);
            lblWelcome.TabIndex = 1;
            lblWelcome.Text = "label2";
            // 
            // lblDate1
            // 
            lblDate1.AutoSize = true;
            lblDate1.Font = new Font("Segoe UI", 16.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
            lblDate1.Location = new Point(402, 167);
            lblDate1.Name = "lblDate1";
            lblDate1.Size = new Size(90, 38);
            lblDate1.TabIndex = 2;
            lblDate1.Text = "label3";
            // 
            // lblMessage
            // 
            lblMessage.AutoSize = true;
            lblMessage.Font = new Font("Segoe UI", 16.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
            lblMessage.Location = new Point(330, 441);
            lblMessage.Name = "lblMessage";
            lblMessage.Size = new Size(90, 38);
            lblMessage.TabIndex = 3;
            lblMessage.Text = "label3";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BorderStyle = BorderStyle.FixedSingle;
            label8.Font = new Font("Segoe UI", 72F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.Location = new Point(469, 233);
            label8.Name = "label8";
            label8.Size = new Size(189, 161);
            label8.TabIndex = 9;
            label8.Text = "⛟";
            // 
            // DashboardControl
            // 
            Controls.Add(label8);
            Controls.Add(lblMessage);
            Controls.Add(lblDate1);
            Controls.Add(lblWelcome);
            Controls.Add(label1);
            Name = "DashboardControl";
            Size = new Size(1083, 607);
            Load += DashboardControl_Load_1;
            ResumeLayout(false);
            PerformLayout();
            // 
            // DashboardControl
            // 

        }

        #endregion

        private Label lblDate;
        private Label label1;
        private Label lblWelcome;
        private Label lblDate1;
        private Panel panel1;
        private Panel panel2;
        private Label label2;
        private Label label4;
        private Label lblMessage;
        private Label label8;
        private Label label3;
    }
}
